crack
=====

Multithreaded brute-force password hash cracker.
